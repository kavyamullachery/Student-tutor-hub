from distutils.log import debug
import re
from click import password_option
from flask import Flask, flash, redirect, render_template, request, session, abort
from flask_mysqldb import MySQL
import os

# DB connection 1
app = Flask(__name__)
app.config['MYSQL_HOST'] = 'localhost'
app.config['MYSQL_USER'] = 'root'
app.config['MYSQL_PASSWORD'] = 'c4eps8yt20'
app.config['MYSQL_DB'] = 'tutor_hub'
mysql = MySQL(app)
app.secret_key = os.urandom(12)

# https://colorhunt.co/palette/383838066163cdbe78f2f2f2

global student_id

@app.route("/")
def index():
    return render_template('home.html')

@app.route("/contact")
def contact():
    return render_template('contact.html')

@app.route("/about")
def about():
    return render_template('about.html')

@app.route("/home",methods=['POST'])
def home():
    if 'choice' in request.form:
        if request.form['choice'] == 'admin' and request.form['action']=='register':
            return render_template('success.html',msg='only one admin allowed',url='/')
        elif request.form['choice'] == 'staff' and request.form['action']=='register':
            return render_template('./staff/registerStaff.html')
        elif 'action' in request.form and request.form['action']=='login':
            return render_template('login.html',role=request.form['choice'])
        elif 'action' in request.form and request.form['action']=='register':
                return render_template('register.html',role=request.form['choice'])
        else:
            return render_template('error.html',msg="invalid input")



@app.route("/admin",methods=['POST'])
def admin():
    if 'email' in session:
        return render_template('./admin/admin_home.html')
    if 'login' in request.form:
        if 'email' in session:
            return render_template('./admin/admin_home.html')
        email = 'admin@gmail.com'
        password = 'admin'
        if email == request.form['email'] and password == request.form['password']:
            session['email'] = email
            return render_template('./admin/admin_home.html')
    return render_template('success.html',msg='credentials did not match',url='/')

@app.route("/admin_actions",methods=['POST'])
def admin_actions():

    if 'tutors' in request.form:
        con = mysql.connection
        cur = con.cursor()
        cur.execute('''SELECT tid,name,sub_id,email,phone FROM tutor_hub.tutor''')
        data = cur.fetchall()
        #delete tutors
        return render_template('./admin/tutors.html',data=data)

    elif 'delete_tutor' in request.form:
        tid = request.form['tid']
        con = mysql.connection
        cur = con.cursor()
        cur.execute('''DELETE FROM `tutor_hub`.`tutor` WHERE (`tid` = %s)''',(tid,))
        con.commit()
        return render_template('success.html',msg='Tutor deleted Succesfully!',url='/admin')
        
    elif 'batches' in request.form:
        return render_template('./admin/batches.html')

    elif 'create_batch' in request.form:
        con = mysql.connection
        cur = con.cursor()
        cur.execute(''' SELECT * FROM tutor_hub.subject''' )
        data = cur.fetchall()
        return render_template('./admin/create_batch.html',data=data)

    elif 'view_batch' in request.form:
        con = mysql.connect
        cur = con.cursor()
        cur.execute(''' select bs.batch_id,b.name,bs.sub_id,s.name,no_of_hrs,fees from batch_subjects bs,subject s,batch b where bs.sub_id=s.sub_id and b.batch_id=bs.batch_id order by bs.batch_id''')
        batch_list = cur.fetchall()
        return render_template('./admin/view_batch.html',data=batch_list)

    elif 'students' in request.form:
        #remove student
        con = mysql.connect
        cur = con.cursor()
        cur.execute('''SELECT name,sid,dob,email,phone,phone_alt,is_subscribed,batch FROM tutor_hub.student''')
        data = cur.fetchall()
        return render_template('./admin/students.html',data=data)


    elif 'logout' in request.form:
        if 'username' in session:
            session.pop('username')
        return render_template('home.html')

    else:
        return render_template('error.html',msg='something went wrong , please login again')


@app.route("/add_batch",methods=['POST'])
def add_batch():
    if 'submit' in request.form:
        batch_name= request.form['name']
        batch_cost= request.form['cost']
        con = mysql.connection
        cur = con.cursor()
        cur.execute('''insert into batch (name,cost) values(%s,%s)''',(batch_name,batch_cost))
        con.commit()
        cur.execute('''select batch_id from batch where name = %s ''',(batch_name,))  
        batch_id = cur.fetchall()[0][0]
        cur.execute(''' INSERT INTO `tutor_hub`.`batch_subjects` (`batch_id`,`sub_id`) VALUES (%s,%s) ''',(batch_id,request.form['sub1']))
        cur.execute(''' INSERT INTO `tutor_hub`.`batch_subjects` (`batch_id`,`sub_id`) VALUES (%s,%s) ''',(batch_id,request.form['sub2']))
        cur.execute(''' INSERT INTO `tutor_hub`.`batch_subjects` (`batch_id`,`sub_id`) VALUES (%s,%s) ''',(batch_id,request.form['sub3']))
        cur.execute(''' INSERT INTO `tutor_hub`.`batch_subjects` (`batch_id`,`sub_id`) VALUES (%s,%s) ''',(batch_id,request.form['sub4']))
        cur.execute(''' INSERT INTO `tutor_hub`.`batch_subjects` (`batch_id`,`sub_id`) VALUES (%s,%s) ''',(batch_id,request.form['sub5']))
        cur.execute(''' INSERT INTO `tutor_hub`.`batch_subjects` (`batch_id`,`sub_id`) VALUES (%s,%s) ''',(batch_id,request.form['sub6']))
        con.commit()
        return admin()
    












@app.route("/student",methods=['POST','GET'])
def student():
    con = mysql.connection
    cur = con.cursor()
    
    if 'register' in request.form:
        if request.form['password']!=request.form['password_confirm']:
            return render_template('success.html',msg='password did not match',url='/')
        cur.execute(''' INSERT INTO `tutor_hub`.`student` (`name`, `dob`, `email`, `password`, `phone`, `phone_alt`, `is_subscribed`) VALUES (%s, %s, %s, %s, %s, %s, 0)''',(request.form['name'],request.form['date'],request.form['email'],request.form['password'],request.form['phone'],request.form['phone2']))
        con.commit()
        return render_template('success.html',msg='User created successfully! Login to continue',url='/')        
    elif 'login' in request.form:
        try:
            email = request.form['email']
            cur.execute(''' SELECT sid,password FROM tutor_hub.student where email=%s ''',(email,))
            data = cur.fetchall()
            sid = data[0][0]
            password = data[0][1]
            if password == request.form['password']:
                session['email'] = email
                session['sid'] = sid
            else:
                return render_template('success.html',msg='credentials did not match,retry',url='/')
        except:
            return render_template('success.html',msg='credentials did not match,retry',url='/')
    if 'sid' in session:
        cur.execute('''select is_subscribed from student where sid=%s''',(session['sid'],))
        is_subscribed = cur.fetchall()[0][0]
        if is_subscribed:
            return render_template('./student/student_home_paid.html')
        else:
            return render_template('./student/student_home_unpaid.html')
    cur.execute('''select is_subscribed from student where sid=%s''',(session['sid'],))
    is_subscribed = cur.fetchall()[0][0]

    if is_subscribed:
        return render_template('./student/student_home_paid.html')
    else:
        return render_template('./student/student_home_unpaid.html')

@app.route('/paid_student_actions',methods=['POST'])
def paid():
    con = mysql.connection
    cur = con.cursor()
    cur.execute('''select batch from student where sid=%s''',(session['sid'],))
    studentBatchId = cur.fetchall()[0][0]

    if 'timetable' in request.form: #timetable is only for online classes tutor will add it
        cur.execute('''select date,name,time,duration,class_link from timetable t ,subject s where t.sub_id = s.sub_id and t.sub_id in (select sub_id from batch_subjects b where b.batch_id = %s )''',(studentBatchId,))
        tt = cur.fetchall()
        l = 0
        if len(tt)>0:
            l = len(tt[0])
        return render_template('./student/timetable.html',tt=tt,len=l,batch=studentBatchId)

    elif 'recordedclass' in request.form:
        cur.execute('''select t.name,vid_name,s.name,topic,link from recorded r,tutor t,subject s where r.tutor_id=t.tid and s.sub_id=r.sub_id''')
        data = cur.fetchall()
        l = 0
        if len(data)>0:
            l = len(data[0])
        return render_template('./student/recordedClasses.html',data=data,len=l)

    elif 'allnotes' in request.form:
        cur.execute('''select t.name,subject,topic,link from notes n,tutor t where t.tid = n.tid''')
        data = cur.fetchall()
        l = 0
        if len(data)>0:
            l = len(data[0])
        return render_template('./student/allNotes.html',data=data,len=l)
       
    elif 'logout' in request.form:
        if 'email' in session:
            session.pop('email')
        return render_template('home.html')
    else:
        return render_template('error.html',msg='something went wrong , please login again')


@app.route("/unpaid_student_actions",methods=['POST'])
def unpaid():
    con = mysql.connection
    cur = con.cursor()
    if 'subscribe' in request.form:
        #show all batches with cost and a button to payment gateway if success then update student table -> batch
        cur.execute('''select * from batch''')
        batches = cur.fetchall()
        return render_template('./student/subscribe.html',data=batches)
        
    elif 'buy notes' in request.form:
        #show all notes available and button to buy after payment
        cur.execute('''select t.name,subject,topic,n.cost,link from notes n,tutor t where t.tid = n.tid''')
        data = cur.fetchall()
        l = 0
        if len(data)>0:
            l = len(data[0])
        return render_template('./student/allNotesPaid.html',data=data,len=l)
    
    elif 'buy' in request.form:
        #show payment gateway
        url = request.form['buy']
        cost = request.form['cost']
        return render_template('./student/notesPayment.html',url=url,cost=cost)
    
    elif 'paid' in request.form:
        url = request.form['url']
        return render_template('./student/viewNotes.html',url=url)
    
    elif 'logout' in request.form:
        if 'username' in session:
            session.pop('username')
        return render_template('home.html')
    else:
        return render_template('error.html',msg='something went wrong , please login again')

@app.route("/staff",methods=['POST','get'])
def staff():
    if 'email' in session:
        return render_template('./staff/staff_home.html')
    con = mysql.connection
    cur = con.cursor()
    if 'login' in request.form:
        try:
            email = request.form['email']
            cur.execute(''' select tid,password from tutor where email=%s ''',(email,))
            data = cur.fetchall()
            tid = data[0][0]
            password = data[0][1]
            if password == request.form['password']:
                session['email'] = email
                session['tid'] = tid
                return render_template('./staff/staff_home.html')
            else:
                return render_template('success.html',msg='credentials did not match,retry',url='/')
        except:
            return render_template('success.html',msg='credentials did not match,retry',url='/')
    elif 'register' in request.form:
        if request.form['password'] != request.form['password_confirm']:
            return render_template('success.html',msg='password did not match',url='/')
        cur.execute('''INSERT INTO `tutor_hub`.`tutor` ( `name`, `email`, `phone`, `password`) VALUES ( %s, %s, %s, %s)''',(request.form['name'],request.form['email'],request.form['phone'],request.form['password']))
        con.commit()
        return render_template('success.html',msg='Login To Continue',url='/')
    return render_template('success.html',msg='Incorrect credentials retry',url='/')

@app.route("/staff_actions",methods=['POST'])
def staffActions():
    if 'add_subject' in request.form:
        return render_template('./staff/addSubject.html')

    elif 'live_class' in request.form:
        return render_template('./staff/liveClass.html')

    elif 'uploadRecorded' in request.form:
        return render_template('./staff/uploadVideo.html')

    elif 'uploadNotes' in request.form:
        return render_template('./staff/uploadNotes.html')

    elif 'logout' in request.form:
        if 'email' in session:
            session.pop('email')
        return render_template('home.html')
    return render_template('error.html',msg='something went wrong , please login again')

@app.route("/staff_work",methods=['post'])
def staffWork():
    con = mysql.connection
    cur = con.cursor()
    cur.execute('SELECT sub_id FROM tutor_hub.tutor where tid=%s',(session['tid'],))
    sub_id = cur.fetchall()[0][0]
    if 'addSubject' in request.form:
        cur.execute('''INSERT INTO `tutor_hub`.`subject`(`no_of_hrs`,`fees`,`name`)VALUES(%s,%s,%s)''',(request.form['hours'],request.form['fees'],request.form['name']))
        con.commit()
        cur.execute('''SELECT sub_id FROM tutor_hub.subject where no_of_hrs=%s and name=%s and fees=%s''',(request.form['hours'],request.form['name'],request.form['fees']))
        sub_id = cur.fetchall()
        cur.execute('''UPDATE `tutor_hub`.`tutor` SET `sub_id` = %s WHERE (`tid` = %s)''',(sub_id,session['tid']))
        con.commit()
        return render_template('success.html',msg='Updated subject',url='/staff')

    elif 'liveClass' in request.form:
        cur.execute('''INSERT INTO `tutor_hub`.`timetable` (`sub_id`, `duration`, `time`, `date`, `tutor_id`, `class_link`) VALUES (%s,%s, %s, %s, %s, %s)''',(sub_id,request.form['duration'],request.form['time'],request.form['date'],session['tid'],request.form['link']))
        con.commit()
        return render_template('success.html',msg='Live class started',url='/staff')
    elif 'uploadRecorded' in request.form:
        cur.execute('''INSERT INTO `tutor_hub`.`recorded` ( `tutor_id`, `sub_id`, `vid_name`, `link`, `topic`) VALUES (%s, %s, %s, %s, %s)''',(session['tid'],sub_id,request.form['name'],request.form['link'],request.form['topic']))
        con.commit()
        return render_template('success.html',msg='class Uploaded',url='/staff')
    elif 'uploadNotes' in request.form:
        cur.execute('''INSERT INTO `tutor_hub`.`notes` (`tid`, `subject`, `topic`, `link`, `cost`) VALUES (%s, %s, %s, %s, %s)''',(session['tid'],request.form['sub'],request.form['topic'],request.form['link'],request.form['cost']))
        con.commit()
        return render_template('success.html',msg='Notes Uploaded',url='/staff')


@app.route("/subscribe",methods=['post'])
def subscribe():
    if 'subscribe' in request.form:
        batch_id = request.form['subscribe']
        cost= request.form['cost']
        con = mysql.connection
        cur = con.cursor()
        cur.execute('''UPDATE `tutor_hub`.`student` SET `is_subscribed` = '1', `batch` = %s WHERE (`sid` = %s)''',(batch_id,session['sid']))
        con.commit()
        return render_template('student/subscribePayment.html',cost=cost)
    if 'paid' in request.form:
        return render_template('./student/student_home_paid.html')